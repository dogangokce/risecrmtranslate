<?php //default_lang.php dosyasından kopyalayarak güncelleme yapın

$lang["example"] = "Örnek";

return $lang;