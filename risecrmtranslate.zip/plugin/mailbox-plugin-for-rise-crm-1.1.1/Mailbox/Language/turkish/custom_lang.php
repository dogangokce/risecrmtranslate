<?php //default_lang.php dosyasından kopyala ve güncelle

$lang["mailbox_ornek"] = "Örnek";

return $lang;