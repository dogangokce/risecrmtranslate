<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["easy_backup"] = "Easy Backup";
$lang["easy_backup_backup_and_download_now"] = "Backup & download now";
$lang["easy_backup_help_message"] = "If you've integrated Google Drive, all backups will be uploaded to there, otherwise it'll be uploaded to your server's local directory.";

return $lang;
