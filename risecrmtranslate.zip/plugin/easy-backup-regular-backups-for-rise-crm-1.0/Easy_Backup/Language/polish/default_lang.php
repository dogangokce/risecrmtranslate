<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["easy_backup"] = "Łatwa kopia zapasowa";
$lang["easy_backup_backup_and_download_now"] = "Utwórz kopię zapasową i pobierz teraz";
$lang["easy_backup_help_message"] = "Jeśli zintegrowałeś Dysk Google, wszystkie kopie zapasowe zostaną tam przesłane, w przeciwnym razie zostaną przesłane do lokalnego katalogu twojego serwera.";

return $lang;
