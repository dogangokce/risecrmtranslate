<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["easy_backup"] = "Sauvegarde facile";
$lang["easy_backup_backup_and_download_now"] = "Sauvegarder et télécharger maintenant";
$lang["easy_backup_help_message"] = "Si vous avez intégré Google Drive, toutes les sauvegardes y seront téléchargées, sinon elles seront téléchargées dans le répertoire local de votre serveur.";

return $lang;
