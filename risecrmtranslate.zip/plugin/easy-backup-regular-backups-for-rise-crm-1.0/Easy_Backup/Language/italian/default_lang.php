<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["easy_backup"] = "Backup facile";
$lang["easy_backup_backup_and_download_now"] = "Backup e download ora";
$lang["easy_backup_help_message"] = "Se hai integrato Google Drive, tutti i backup verranno caricati lì, altrimenti verranno caricati nella directory locale del tuo server.";

return $lang;
