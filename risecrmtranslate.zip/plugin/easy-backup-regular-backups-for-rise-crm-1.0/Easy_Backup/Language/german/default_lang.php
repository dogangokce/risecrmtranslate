<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["easy_backup"] = "Einfaches Backup";
$lang["easy_backup_backup_and_download_now"] = "Jetzt sichern und herunterladen";
$lang["easy_backup_help_message"] = "Wenn Sie Google Drive integriert haben, werden alle Backups dorthin hochgeladen, andernfalls werden sie in das lokale Verzeichnis Ihres Servers hochgeladen.";

return $lang;
