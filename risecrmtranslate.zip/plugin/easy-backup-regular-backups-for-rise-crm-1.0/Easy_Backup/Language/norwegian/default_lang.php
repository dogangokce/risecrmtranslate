<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["easy_backup"] = "Enkel sikkerhetskopiering";
$lang["easy_backup_backup_and_download_now"] = "Sikkerhetskopier og last ned nå";
$lang["easy_backup_help_message"] = "Hvis du har integrert Google Disk, blir alle sikkerhetskopier lastet opp der, ellers blir de lastet opp til serverens lokale katalog.";

return $lang;
