<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["easy_backup"] = "Copia de seguridad fácil";
$lang["easy_backup_backup_and_download_now"] = "Copia de seguridad y descarga ahora";
$lang["easy_backup_help_message"] = "Si ha integrado Google Drive, todas las copias de seguridad se cargarán allí; de lo contrario, se cargarán en el directorio local de su servidor.";

return $lang;
