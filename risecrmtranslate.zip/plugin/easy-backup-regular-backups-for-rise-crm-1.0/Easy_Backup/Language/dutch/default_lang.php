<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["easy_backup"] = "Eenvoudige back-up";
$lang["easy_backup_backup_and_download_now"] = "Back-up en download nu";
$lang["easy_backup_help_message"] = "Als je Google Drive hebt geïntegreerd, worden alle back-ups daar naartoe geüpload, anders worden ze geüpload naar de lokale map van je server.";

return $lang;
