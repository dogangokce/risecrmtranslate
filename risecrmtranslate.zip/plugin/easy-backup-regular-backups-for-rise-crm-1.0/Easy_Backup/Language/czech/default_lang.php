<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["easy_backup"] = "Snadné zálohování";
$lang["easy_backup_backup_and_download_now"] = "Zálohovat a stáhnout nyní";
$lang["easy_backup_help_message"] = "Pokud jste integrovali Disk Google, budou do něj nahrány všechny zálohy, jinak budou nahrány do místního adresáře vašeho serveru.";

return $lang;
