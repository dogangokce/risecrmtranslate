<?php //default_lang.php dosyasından kopyala ve güncelle

$lang["easy_backup_example"] = "Örnek";

return $lang;