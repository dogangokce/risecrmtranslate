<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["easy_backup"] = "Εύκολη δημιουργία αντιγράφων ασφαλείας";
$lang["easy_backup_backup_and_download_now"] = "Δημιουργία αντιγράφων ασφαλείας & λήψη τώρα";
$lang["easy_backup_help_message"] = "Εάν έχετε ενσωματώσει το Google Drive, όλα τα αντίγραφα ασφαλείας θα μεταφορτωθούν εκεί, διαφορετικά θα μεταφορτωθούν στον τοπικό κατάλογο του διακομιστή σας.";

return $lang;
