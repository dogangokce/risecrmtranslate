<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["easy_backup"] = "Backup fácil";
$lang["easy_backup_backup_and_download_now"] = "Backup e download agora";
$lang["easy_backup_help_message"] = "Se você integrou o Google Drive, todos os backups serão enviados para lá, caso contrário, serão enviados para o diretório local do seu servidor.";

return $lang;
