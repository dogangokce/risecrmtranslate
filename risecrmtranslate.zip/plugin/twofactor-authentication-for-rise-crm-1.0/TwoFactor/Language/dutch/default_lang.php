<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["twofactor"] = "Twee-factor";
$lang["twofactor_settings"] = "Twee-factor instellingen";
$lang["twofactor_email_subject"] = "E-mail onderwerp";
$lang["twofactor_email_message"] = "E-mailbericht";
$lang["twofactor_twofactor_authentication"] = "Twee-factor authenticatie";
$lang["twofactor_enable_twofactor_authentication"] = "Schakel twee-factor authenticatie in";
$lang["twofactor_info_text"] = "Voordat u uitlogt, opent u een nieuwe browser en controleert u of de twee-factor-authenticatie werkt.";
$lang["twofactor_code"] = "Code";
$lang["twofactor_code_expaired_message"] = "De tweefactorcode is verlopen of er is iets misgegaan.";
$lang["twofactor_code_message"] = "Er is een OTP naar je e-mailadres gestuurd. Pak die op om verder te gaan.";
$lang["twofactor_code_success_message"] = "Succesvol ingelogd. Omleiden naar het dashboard...";
$lang["twofactor_continue"] = "Doorgaan";
$lang["twofactor_not_you"] = "Niet jij?";
$lang["twofactor_restore_email_message_to_default"] = "Herstel e-mailbericht naar standaard";
$lang["twofactor_email_message_restored"] = "Het e-mailbericht is teruggezet naar de standaardwaarde!";

return $lang;
