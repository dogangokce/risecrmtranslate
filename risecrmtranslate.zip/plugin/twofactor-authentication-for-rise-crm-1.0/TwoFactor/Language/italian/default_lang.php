<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["twofactor"] = "Due fattori";
$lang["twofactor_settings"] = "Impostazioni a due fattori";
$lang["twofactor_email_subject"] = "Oggetto email";
$lang["twofactor_email_message"] = "Messaggio e-mail";
$lang["twofactor_twofactor_authentication"] = "Autenticazione a due fattori";
$lang["twofactor_enable_twofactor_authentication"] = "Abilita l'autenticazione a due fattori";
$lang["twofactor_info_text"] = "Prima di uscire, apri un nuovo browser e assicurati che l'autenticazione a due fattori funzioni.";
$lang["twofactor_code"] = "Codice";
$lang["twofactor_code_expaired_message"] = "Il codice a due fattori è scaduto o qualcosa è andato storto.";
$lang["twofactor_code_message"] = "Una OTP è stata inviata alla tua email. Prendila per continuare.";
$lang["twofactor_code_success_message"] = "Accesso effettuato con successo. Reindirizzamento alla dashboard...";
$lang["twofactor_continue"] = "Continua";
$lang["twofactor_not_you"] = "Non sei tu?";
$lang["twofactor_restore_email_message_to_default"] = "Ripristina il messaggio email ai valori predefiniti";
$lang["twofactor_email_message_restored"] = "Il messaggio email è stato ripristinato ai valori predefiniti!";

return $lang;
