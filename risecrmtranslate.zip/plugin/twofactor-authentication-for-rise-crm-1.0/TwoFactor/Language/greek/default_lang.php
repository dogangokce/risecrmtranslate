<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["twofactor"] = "Δύο παράγοντες";
$lang["twofactor_settings"] = "Ρυθμίσεις δύο παραγόντων";
$lang["twofactor_email_subject"] = "Θέμα ηλεκτρονικού ταχυδρομείου";
$lang["twofactor_email_message"] = "Μήνυμα ηλεκτρονικού ταχυδρομείου";
$lang["twofactor_twofactor_authentication"] = "Έλεγχος ταυτότητας δύο παραγόντων";
$lang["twofactor_enable_twofactor_authentication"] = "Ενεργοποίηση ελέγχου ταυτότητας δύο παραγόντων";
$lang["twofactor_info_text"] = "Πριν αποσυνδεθείτε, ανοίξτε ένα νέο πρόγραμμα περιήγησης και βεβαιωθείτε ότι λειτουργεί ο έλεγχος ταυτότητας δύο παραγόντων.";
$lang["twofactor_code"] = "Κωδικός";
$lang["twofactor_code_expaired_message"] = "Ο κωδικός δύο παραγόντων έληξε ή κάτι πήγε στραβά.";
$lang["twofactor_code_message"] = "Έχει σταλεί ένα OTP στο email σας. Πιάστε το για να συνεχίσετε.";
$lang["twofactor_code_success_message"] = "Έχετε συνδεθεί επιτυχώς. Ανακατεύθυνση στον πίνακα ελέγχου ...";
$lang["twofactor_continue"] = "Συνέχεια";
$lang["twofactor_not_you"] = "Δεν είσαι εσύ;";
$lang["twofactor_restore_email_message_to_default"] = "Επαναφορά μηνύματος email στην προεπιλογή";
$lang["twofactor_email_message_restored"] = "Το μήνυμα ηλεκτρονικού ταχυδρομείου επανήλθε στην προεπιλογή!";

return $lang;
