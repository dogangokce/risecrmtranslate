<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["twofactor"] = "Dois fatores";
$lang["twofactor_settings"] = "Configurações de dois fatores";
$lang["twofactor_email_subject"] = "Assunto do email";
$lang["twofactor_email_message"] = "Mensagem de e-mail";
$lang["twofactor_twofactor_authentication"] = "Autenticação de dois fatores";
$lang["twofactor_enable_twofactor_authentication"] = "Habilitar autenticação de dois fatores";
$lang["twofactor_info_text"] = "Antes de sair, abra um novo navegador e certifique-se de que a autenticação de dois fatores está funcionando.";
$lang["twofactor_code"] = "Código";
$lang["twofactor_code_expair_message"] = "O código de dois fatores expirou ou algo deu errado.";
$lang["twofactor_code_message"] = "Um OTP foi enviado para o seu e-mail. Por favor, pegue-o para continuar.";
$lang["twofactor_code_success_message"] = "Conectado com sucesso. Redirecionando para o painel ...";
$lang["twofactor_continue"] = "Continuar";
$lang["twofactor_not_you"] = "Não é você?";
$lang["twofactor_restore_email_message_to_default"] = "Restaurar mensagem de e-mail para o padrão";
$lang["twofactor_email_message_restored"] = "A mensagem de e-mail foi restaurada ao padrão!";

return $lang;
