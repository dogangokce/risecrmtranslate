<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["twofactor"] = "Dvoufaktorový";
$lang["twofactor_settings"] = "Dvoufaktorové nastavení";
$lang["twofactor_email_subject"] = "Předmět e -mailu";
$lang["twofactor_email_message"] = "E -mailová zpráva";
$lang["twofactor_twofactor_authentication"] = "Dvoufaktorová autentizace";
$lang["twofactor_enable_twofactor_authentication"] = "Povolit dvoufaktorové ověřování";
$lang["twofactor_info_text"] = "Než se odhlásíte, otevřete si nový prohlížeč a zkontrolujte, zda funguje dvoufaktorové ověřování.";
$lang["twofactor_code"] = "Kód";
$lang["twofactor_code_expaired_message"] = "Platnost dvoufaktorového kódu vypršela nebo se něco pokazilo.";
$lang["twofactor_code_message"] = "Na váš e -mail bylo odesláno jednorázové heslo. Chcete -li pokračovat, chyťte ho.";
$lang["twofactor_code_success_message"] = "Úspěšně přihlášen. Přesměrování na hlavní panel ...";
$lang["twofactor_continue"] = "Pokračovat";
$lang["twofactor_not_you"] = "Nejste vy?";
$lang["twofactor_restore_email_message_to_default"] = "Obnovit výchozí e -mailové zprávy";
$lang["twofactor_email_message_restored"] = "E -mailová zpráva byla obnovena na výchozí!";

return $lang;
