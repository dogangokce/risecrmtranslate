<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["twofactor"] = "Dwuczynnikowy";
$lang["twofactor_settings"] = "Ustawienia dwuskładnikowe";
$lang["twofactor_email_subject"] = "Temat e-maila";
$lang["twofactor_email_message"] = "Wiadomość e-mail";
$lang["twofactor_twofactor_authentication"] = "Uwierzytelnianie dwuskładnikowe";
$lang["twofactor_enable_twofactor_authentication"] = "Włącz uwierzytelnianie dwuskładnikowe";
$lang["twofactor_info_text"] = "Zanim się wylogujesz, otwórz nową przeglądarkę i upewnij się, że uwierzytelnianie dwuskładnikowe działa.";
$lang["twofactor_code"] = "Kod";
$lang["twofactor_code_expaired_message"] = "Kod dwuskładnikowy wygasł lub coś poszło nie tak.";
$lang["twofactor_code_message"] = "OTP został wysłany na twój e-mail. Proszę pobrać, aby kontynuować.";
$lang["twofactor_code_success_message"] = "Zalogowano pomyślnie. Przekierowanie do pulpitu nawigacyjnego...";
$lang["twofactor_continue"] = "Kontynuuj";
$lang["twofactor_not_you"] = "Nie ty?";
$lang["twofactor_restore_email_message_to_default"] = "Przywróć domyślne wiadomości e-mail";
$lang["twofactor_email_message_restored"] = "Wiadomość e-mail została przywrócona do wartości domyślnych!";

return $lang;
