<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["twofactor"] = "To-faktor";
$lang["twofactor_settings"] = "To-faktor innstillinger";
$lang["twofactor_email_subject"] = "Emne på e -post";
$lang["twofactor_email_message"] = "E -postmelding";
$lang["twofactor_twofactor_authentication"] = "To-faktor autentisering";
$lang["twofactor_enable_twofactor_authentication"] = "Aktiver tofaktorautentisering";
$lang["twofactor_info_text"] = "Før du logger ut, må du åpne en ny nettleser og kontrollere at tofaktorautentiseringen fungerer.";
$lang["twofactor_code"] = "Kode";
$lang["twofactor_code_expaired_message"] = "To-faktor koden er utløpt eller noe gikk galt.";
$lang["twofactor_code_message"] = "En OTP har blitt sendt til e -posten din. Ta det for å fortsette.";
$lang["twofactor_code_success_message"] = "Logget inn vellykket. Viderekobler til dashbordet ...";
$lang["twofactor_continue"] = "Fortsett";
$lang["twofactor_not_you"] = "Ikke du?";
$lang["twofactor_restore_email_message_to_default"] = "Gjenopprett e -post til standard";
$lang["twofactor_email_message_restored"] = "E -postmeldingen er gjenopprettet til standard!";

return $lang;
