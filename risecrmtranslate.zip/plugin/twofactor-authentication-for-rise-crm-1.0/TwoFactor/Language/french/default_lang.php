<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["twofactor"] = "Deux facteurs";
$lang["twofactor_settings"] = "Paramètres à deux facteurs";
$lang["twofactor_email_subject"] = "Objet de l'e-mail";
$lang["twofactor_email_message"] = "E-mail";
$lang["twofactor_twofactor_authentication"] = "Authentification à deux facteurs";
$lang["twofactor_enable_twofactor_authentication"] = "Activer l'authentification à deux facteurs";
$lang["twofactor_info_text"] = "Avant de vous déconnecter, veuillez ouvrir un nouveau navigateur et vous assurer que l'authentification à deux facteurs fonctionne.";
$lang["twofactor_code"] = "Code";
$lang["twofactor_code_expaired_message"] = "Le code à deux facteurs a expiré ou quelque chose s'est mal passé.";
$lang["twofactor_code_message"] = "Un OTP a été envoyé à votre e-mail. Veuillez le saisir pour continuer.";
$lang["twofactor_code_success_message"] = "Connecté avec succès. Redirection vers le tableau de bord...";
$lang["twofactor_continue"] = "Continuer";
$lang["twofactor_not_you"] = "Pas vous ?";
$lang["twofactor_restore_email_message_to_default"] = "Restaurer l'e-mail par défaut";
$lang["twofactor_email_message_restored"] = "Le message électronique a été restauré par défaut !";

return $lang;
