<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["twofactor"] = "zweifaktor";
$lang["twofactor_settings"] = "Zwei-Faktor-Einstellungen";
$lang["twofactor_email_subject"] = "E-Mail-Betreff";
$lang["twofactor_email_message"] = "E-Mail-Nachricht";
$lang["twofactor_twofactor_authentication"] = "Zwei-Faktor-Authentifizierung";
$lang["twofactor_enable_twofactor_authentication"] = "Zwei-Faktor-Authentifizierung aktivieren";
$lang["twofactor_info_text"] = "Bevor Sie sich abmelden, öffnen Sie bitte einen neuen Browser und stellen Sie sicher, dass die Zwei-Faktor-Authentifizierung funktioniert.";
$lang["twofactor_code"] = "Code";
$lang["twofactor_code_expaired_message"] = "Der Zwei-Faktor-Code ist abgelaufen oder etwas ist schief gelaufen.";
$lang["twofactor_code_message"] = "Ein OTP wurde an Ihre E-Mail gesendet. Bitte nehmen Sie es, um fortzufahren.";
$lang["twofactor_code_success_message"] = "Erfolgreich eingeloggt. Weiterleitung zum Dashboard...";
$lang["twofactor_continue"] = "Weiter";
$lang["twofactor_not_you"] = "Du nicht?";
$lang["twofactor_restore_email_message_to_default"] = "E-Mail-Nachricht auf Standard zurücksetzen";
$lang["twofactor_email_message_restored"] = "Die E-Mail-Nachricht wurde auf die Standardeinstellungen zurückgesetzt!";

return $lang;
