<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["twofactor"] = "Двухфакторный";
$lang["twofactor_settings"] = "Двухфакторные настройки";
$lang["twofactor_email_subject"] = "Тема письма";
$lang["twofactor_email_message"] = "Электронное сообщение";
$lang["twofactor_twofactor_authentication"] = "Двухфакторная аутентификация";
$lang["twofactor_enable_twofactor_authentication"] = "Включить двухфакторную аутентификацию";
$lang["twofactor_info_text"] = "Перед выходом откройте новый браузер и убедитесь, что двухфакторная аутентификация работает.";
$lang["twofactor_code"] = "Код";
$lang["twofactor_code_expaired_message"] = "Срок действия двухфакторного кода истек или что-то пошло не так.";
$lang["twofactor_code_message"] = "На вашу электронную почту был отправлен одноразовый пароль. Используйте его, чтобы продолжить.";
$lang["twofactor_code_success_message"] = "Выполнен вход в систему. Перенаправление на панель управления ...";
$lang["twofactor_continue"] = "Продолжить";
$lang["twofactor_not_you"] = "Не ты?";
$lang["twofactor_restore_email_message_to_default"] = "Восстановить сообщение электронной почты по умолчанию";
$lang["twofactor_email_message_restored"] = "Сообщение электронной почты восстановлено по умолчанию!";

return $lang;
