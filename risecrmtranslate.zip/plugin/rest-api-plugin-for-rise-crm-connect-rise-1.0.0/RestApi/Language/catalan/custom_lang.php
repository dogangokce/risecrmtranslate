<?php
//default_lang.php dosyasından kopyala ve güncelle

$lang["example"]            = "Örnek";
$lang["rest_api_main_menu"] = "API";
return $lang;
