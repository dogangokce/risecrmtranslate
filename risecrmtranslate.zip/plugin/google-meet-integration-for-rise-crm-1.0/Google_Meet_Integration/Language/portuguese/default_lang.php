<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["google_meet_integration"] = "Integração do Google Meet";
$lang["google_meet_integration_meetings"] = "Reuniões";
$lang["google_meet_integration_topic"] = "Tópico";
$lang["google_meet_meetings"] = "reuniões do Google Meet";
$lang["google_meet"] = "Google Meet";
$lang["google_meet_integration_join_meeting"] = "Participar da reunião";
$lang["google_meet_integration_other_settings"] = "Outras configurações";
$lang["google_meet_integration_integrate_google_meet"] = "Integrar o Google Meet";
$lang["google_meet_integration_who_can_manage_meetings"] = "Quem pode gerenciar reuniões";
$lang["google_meet_integration_users_help_message"] = "Especifique apenas membros da equipe não administradores. Os administradores sempre terão acesso.";
$lang["google_meet_integration_client_can_access_meetings"] = "O cliente pode acessar as reuniões?";
$lang["google_meet_integration_meeting_time"] = "Hora da reunião";
$lang["google_meet_integration_join_url"] = "URL de adesão";
$lang["google_meet_integration_add_meeting"] = "Adicionar reunião";
$lang["google_meet_integration_edit_meeting"] = "Editar reunião";
$lang["google_meet_integration_delete_meeting"] = "Excluir reunião";
$lang["google_meet_integration_all_client_contacts"] = "Todos os contatos do cliente";
$lang["google_meet_integration_choose_client_contacts"] = "Escolha os contatos do cliente";
$lang["google_meet_integration_upcoming"] = "Próximos";
$lang["google_meet_integration_recent"] = "Recentes";
$lang["google_meet_integration_past"] = "Passado";

return $lang;
