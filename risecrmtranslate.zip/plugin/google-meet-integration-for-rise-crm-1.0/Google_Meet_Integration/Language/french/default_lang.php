<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["google_meet_integration"] = "Intégration de Google Meet";
$lang["google_meet_integration_meetings"] = "Réunions";
$lang["google_meet_integration_topic"] = "Sujet";
$lang["google_meet_meetings"] = "Réunions Google Meet";
$lang["google_meet"] = "Google Meet";
$lang["google_meet_integration_join_meeting"] = "Rejoindre la réunion";
$lang["google_meet_integration_other_settings"] = "Autres paramètres";
$lang["google_meet_integration_integrate_google_meet"] = "Intégrer Google Meet";
$lang["google_meet_integration_who_can_manage_meetings"] = "Qui peut gérer les réunions";
$lang["google_meet_integration_users_help_message"] = "Spécifiez uniquement les membres de l'équipe non-administrateurs. Les administrateurs auront toujours accès.";
$lang["google_meet_integration_client_can_access_meetings"] = "Le client peut accéder aux réunions ?";
$lang["google_meet_integration_meeting_time"] = "Heure de la réunion";
$lang["google_meet_integration_join_url"] = "Rejoindre l'URL";
$lang["google_meet_integration_add_meeting"] = "Ajouter une réunion";
$lang["google_meet_integration_edit_meeting"] = "Modifier la réunion";
$lang["google_meet_integration_delete_meeting"] = "Supprimer la réunion";
$lang["google_meet_integration_all_client_contacts"] = "Tous les contacts clients";
$lang["google_meet_integration_choose_client_contacts"] = "Choisir les contacts clients";
$lang["google_meet_integration_upcoming"] = "À venir";
$lang["google_meet_integration_recent"] = "Récent";
$lang["google_meet_integration_past"] = "Passé";

return $lang;
