<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["google_meet_integration"] = "Google Meet-integrering";
$lang["google_meet_integration_meetings"] = "Møter";
$lang["google_meet_integration_topic"] = "Emne";
$lang["google_meet_meetings"] = "Google Meet-møter";
$lang["google_meet"] = "Google Meet";
$lang["google_meet_integration_join_meeting"] = "Bli med i møte";
$lang["google_meet_integration_other_settings"] = "Andre innstillinger";
$lang["google_meet_integration_integrate_google_meet"] = "Integrer Google Meet";
$lang["google_meet_integration_who_can_manage_meetings"] = "Hvem kan administrere møter";
$lang["google_meet_integration_users_help_message"] = "Spesifiser bare ikke-admin teammedlemmer. Administratorer vil alltid få tilgang.";
$lang["google_meet_integration_client_can_access_meetings"] = "Klient kan få tilgang til møter?";
$lang["google_meet_integration_meeting_time"] = "Møtetid";
$lang["google_meet_integration_join_url"] = "Bli med URL";
$lang["google_meet_integration_add_meeting"] = "Legg til møte";
$lang["google_meet_integration_edit_meeting"] = "Rediger møte";
$lang["google_meet_integration_delete_meeting"] = "Slett møte";
$lang["google_meet_integration_all_client_contacts"] = "Alle klientkontakter";
$lang["google_meet_integration_choose_client_contacts"] = "Velg klientkontakter";
$lang["google_meet_integration_upcoming"] = "Kommende";
$lang["google_meet_integration_recent"] = "Nylig";
$lang["google_meet_integration_past"] = "Fortid";

return $lang;
