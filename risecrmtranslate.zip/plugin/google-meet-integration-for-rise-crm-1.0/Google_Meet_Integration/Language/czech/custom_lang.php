<?php //default_lang.php dosyasından kopyala ve güncelle

$lang["google_meet_integration_example"] = "Örnek";

return $lang;