<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["google_meet_integration"] = "Ενσωμάτωση Google Meet";
$lang["google_meet_integration_meetings"] = "Συναντήσεις";
$lang["google_meet_integration_topic"] = "Θέμα";
$lang["google_meet_meetings"] = "Συναντήσεις Google Meet";
$lang["google_meet"] = "Google Meet";
$lang["google_meet_integration_join_meeting"] = "Συμμετοχή στη συνάντηση";
$lang["google_meet_integration_other_settings"] = "Άλλες ρυθμίσεις";
$lang["google_meet_integration_integrate_google_meet"] = "Ενσωμάτωση του Google Meet";
$lang["google_meet_integration_who_can_manage_meetings"] = "Ποιος μπορεί να διαχειριστεί συσκέψεις";
$lang["google_meet_integration_users_help_message"] = "Καθορίστε μόνο μέλη της ομάδας που δεν είναι διαχειριστές. Οι διαχειριστές θα έχουν πάντα πρόσβαση.";
$lang["google_meet_integration_client_can_access_meetings"] = "Ο πελάτης μπορεί να έχει πρόσβαση σε συσκέψεις;";
$lang["google_meet_integration_meeting_time"] = "Ώρα συνάντησης";
$lang["google_meet_integration_join_url"] = "Διεύθυνση URL συμμετοχής";
$lang["google_meet_integration_add_meeting"] = "Προσθήκη συνάντησης";
$lang["google_meet_integration_edit_meeting"] = "Επεξεργασία συνάντησης";
$lang["google_meet_integration_delete_meeting"] = "Διαγραφή συνάντησης";
$lang["google_meet_integration_all_client_contacts"] = "Όλες οι επαφές πελατών";
$lang["google_meet_integration_choose_client_contacts"] = "Επιλογή επαφών πελατών";
$lang["google_meet_integration_upcoming"] = "Προσεχόμενα";
$lang["google_meet_integration_recent"] = "Πρόσφατα";
$lang["google_meet_integration_past"] = "Παρελθόν";

return $lang;
