<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["google_meet_integration"] = "Integracja z Google Meet";
$lang["google_meet_integration_meetings"] = "Spotkania";
$lang["google_meet_integration_topic"] = "Temat";
$lang["google_meet_meetings"] = "Spotkania Google Meet";
$lang["google_meet"] = "Google Meet";
$lang["google_meet_integration_join_meeting"] = "Dołącz do spotkania";
$lang["google_meet_integration_other_settings"] = "Inne ustawienia";
$lang["google_meet_integration_integrate_google_meet"] = "Zintegruj Google Meet";
$lang["google_meet_integration_who_can_manage_meetings"] = "Kto może zarządzać spotkaniami";
$lang["google_meet_integration_users_help_message"] = "Określ tylko członków zespołu niebędących administratorami. Administratorzy zawsze będą mieli dostęp.";
$lang["google_meet_integration_client_can_access_meetings"] = "Klient ma dostęp do spotkań?";
$lang["google_meet_integration_meeting_time"] = "Czas spotkania";
$lang["google_meet_integration_join_url"] = "Dołącz URL";
$lang["google_meet_integration_add_meeting"] = "Dodaj spotkanie";
$lang["google_meet_integration_edit_meeting"] = "Edytuj spotkanie";
$lang["google_meet_integration_delete_meeting"] = "Usuń spotkanie";
$lang["google_meet_integration_all_client_contacts"] = "Wszystkie kontakty klientów";
$lang["google_meet_integration_choose_client_contacts"] = "Wybierz kontakty klienta";
$lang["google_meet_integration_upcoming"] = "Nadchodzące";
$lang["google_meet_integration_recent"] = "Ostatnie";
$lang["google_meet_integration_past"] = "Przeszłość";

return $lang;
