<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["google_meet_integration"] = "Google Meet Entegrasyonu";
$lang["google_meet_integration_meetings"] = "Toplantılar";
$lang["google_meet_integration_topic"] = "Konu";
$lang["google_meet_meetings"] = "Google Meet toplantıları";
$lang["google_meet"] = "Google Meet";
$lang["google_meet_integration_join_meeting"] = "Toplantıya katıl";
$lang["google_meet_integration_other_settings"] = "Diğer ayarlar";
$lang["google_meet_integration_integrate_google_meet"] = "Google Meet'i entegre et";
$lang["google_meet_integration_who_can_manage_meetings"] = "Kim toplantıları yönetebilir";
$lang["google_meet_integration_users_help_message"] = "Yalnızca yönetici olmayan ekip üyelerini belirtin. Yöneticiler her zaman erişebilir.";
$lang["google_meet_integration_client_can_access_meetings"] = "Müşteri toplantılara erişebilir mi?";
$lang["google_meet_integration_meeting_time"] = "Toplantı zamanı";
$lang["google_meet_integration_join_url"] = "Katılma URL'si";
$lang["google_meet_integration_add_meeting"] = "Toplantı ekle";
$lang["google_meet_integration_edit_meeting"] = "Toplantıyı düzenle";
$lang["google_meet_integration_delete_meeting"] = "Toplantıyı sil";
$lang["google_meet_integration_all_client_contacts"] = "Tüm müşteri iletişimleri";
$lang["google_meet_integration_choose_client_contacts"] = "Müşteri iletişimlerini seçin";
$lang["google_meet_integration_upcoming"] = "Yaklaşan";
$lang["google_meet_integration_recent"] = "Son yapılanlar";
$lang["google_meet_integration_past"] = "Geçmiş";

return $lang;
