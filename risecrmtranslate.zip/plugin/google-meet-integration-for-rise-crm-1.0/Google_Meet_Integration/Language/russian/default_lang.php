<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["google_meet_integration"] = "Интеграция с Google Meet";
$lang["google_meet_integration_meetings"] = "Встречи";
$lang["google_meet_integration_topic"] = "Тема";
$lang["google_meet_meetings"] = "Встречи Google Meet";
$lang["google_meet"] = "Google Meet";
$lang["google_meet_integration_join_meeting"] = "Присоединиться к встрече";
$lang["google_meet_integration_other_settings"] = "Другие настройки";
$lang["google_meet_integration_integrate_google_meet"] = "Интегрировать Google Meet";
$lang["google_meet_integration_who_can_manage_meetings"] = "Кто может управлять собраниями";
$lang["google_meet_integration_users_help_message"] = "Укажите только членов команды, не являющихся администраторами. Администраторы всегда получат доступ.";
$lang["google_meet_integration_client_can_access_meetings"] = "Клиент может получить доступ к собраниям?";
$lang["google_meet_integration_meeting_time"] = "Время встречи";
$lang["google_meet_integration_join_url"] = "URL присоединения";
$lang["google_meet_integration_add_meeting"] = "Добавить встречу";
$lang["google_meet_integration_edit_meeting"] = "Редактировать встречу";
$lang["google_meet_integration_delete_meeting"] = "Удалить встречу";
$lang["google_meet_integration_all_client_contacts"] = "Все контакты клиентов";
$lang["google_meet_integration_choose_client_contacts"] = "Выбрать контакты клиента";
$lang["google_meet_integration_upcoming"] = "Предстоящие";
$lang["google_meet_integration_recent"] = "Недавние";
$lang["google_meet_integration_past"] = "Прошлый";

return $lang;
