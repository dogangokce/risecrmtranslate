<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["microsoft_teams_integration"] = "Microsoft Teams-Integration";
$lang["microsoft_teams_integration_meetings"] = "Besprechungen";
$lang["microsoft_teams_integration_topic"] = "Thema";
$lang["microsoft_team_meetings"] = "Teams-Meetings";
$lang["microsoft_teams_integration_join_meeting"] = "Meeting beitreten";
$lang["microsoft_teams_integration_other_settings"] = "Andere Einstellungen";
$lang["microsoft_teams_integration_integrate_microsoft_teams"] = "Microsoft Teams integrieren";
$lang["microsoft_teams_integration_who_can_manage_meetings"] = "Wer kann Meetings verwalten";
$lang["microsoft_teams_integration_users_help_message"] = "Geben Sie nur Nicht-Administrator-Teammitglieder an. Administratoren erhalten immer Zugriff.";
$lang["microsoft_teams_integration_client_can_access_meetings"] = "Kunde kann auf Meetings zugreifen?";
$lang["microsoft_teams_integration_meeting_time"] = "Besprechungszeit";
$lang["microsoft_teams_integration_join_url"] = "Beitritts-URL";
$lang["microsoft_teams_integration_add_meeting"] = "Meeting hinzufügen";
$lang["microsoft_teams_integration_edit_meeting"] = "Meeting bearbeiten";
$lang["microsoft_teams_integration_delete_meeting"] = "Meeting löschen";
$lang["microsoft_teams_integration_all_client_contacts"] = "Alle Kundenkontakte";
$lang["microsoft_teams_integration_choose_client_contacts"] = "Kundenkontakte auswählen";
$lang["microsoft_teams_integration_upcoming"] = "Bevorstehend";
$lang["microsoft_teams_integration_recent"] = "Zuletzt";
$lang["microsoft_teams_integration_past"] = "Vergangenheit";

return $lang;
