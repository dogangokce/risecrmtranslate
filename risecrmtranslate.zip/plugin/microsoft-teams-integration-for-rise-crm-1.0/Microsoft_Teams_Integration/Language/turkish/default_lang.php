<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["microsoft_teams_integration"] = "Microsoft Teams Entegrasyonu";
$lang["microsoft_teams_integration_meetings"] = "Toplantılar";
$lang["microsoft_teams_integration_topic"] = "Konu";
$lang["microsoft_team_meetings"] = "Ekip toplantıları";
$lang["microsoft_teams_integration_join_meeting"] = "Toplantıya katıl";
$lang["microsoft_teams_integration_other_settings"] = "Diğer ayarlar";
$lang["microsoft_teams_integration_integrate_microsoft_teams"] = "Microsoft Teams entegrasyonu";
$lang["microsoft_teams_integration_who_can_manage_meetings"] = "Toplantıları kim yönetebilir";
$lang["microsoft_teams_integration_users_help_message"] = "Sadece yönetici olmayan takım üyelerini belirtin. Yöneticiler her zaman erişebilir.";
$lang["microsoft_teams_integration_client_can_access_meetings"] = "Müşteri toplantılara erişebilir mi?";
$lang["microsoft_teams_integration_meeting_time"] = "Toplantı saati";
$lang["microsoft_teams_integration_join_url"] = "Katılma URL'si";
$lang["microsoft_teams_integration_add_meeting"] = "Toplantı ekle";
$lang["microsoft_teams_integration_edit_meeting"] = "Toplantıyı düzenle";
$lang["microsoft_teams_integration_delete_meeting"] = "Toplantıyı sil";
$lang["microsoft_teams_integration_all_client_contacts"] = "Tüm müşteri kişileri";
$lang["microsoft_teams_integration_choose_client_contacts"] = "Müşteri kişilerini seçin";
$lang["microsoft_teams_integration_upcoming"] = "Yaklaşan";
$lang["microsoft_teams_integration_recent"] = "Son";
$lang["microsoft_teams_integration_past"] = "Geçmiş";

return $lang;
