<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["microsoft_teams_integration"] = "Integração com Microsoft Teams";
$lang["microsoft_teams_integration_meetings"] = "Reuniões";
$lang["microsoft_teams_integration_topic"] = "Tópico";
$lang["microsoft_team_meetings"] = "reuniões do Teams";
$lang["microsoft_teams_integration_join_meeting"] = "Participar da reunião";
$lang["microsoft_teams_integration_other_settings"] = "Outras configurações";
$lang["microsoft_teams_integration_integrate_microsoft_teams"] = "Integrar Microsoft Teams";
$lang["microsoft_teams_integration_who_can_manage_meetings"] = "Quem pode gerenciar reuniões";
$lang["microsoft_teams_integration_users_help_message"] = "Especifique apenas membros não-administradores da equipe. Os administradores sempre terão acesso.";
$lang["microsoft_teams_integration_client_can_access_meetings"] = "O cliente pode acessar as reuniões?";
$lang["microsoft_teams_integration_meeting_time"] = "Hora da reunião";
$lang["microsoft_teams_integration_join_url"] = "URL de inscrição";
$lang["microsoft_teams_integration_add_meeting"] = "Adicionar reunião";
$lang["microsoft_teams_integration_edit_meeting"] = "Editar reunião";
$lang["microsoft_teams_integration_delete_meeting"] = "Excluir reunião";
$lang["microsoft_teams_integration_all_client_contacts"] = "Todos os contatos do cliente";
$lang["microsoft_teams_integration_choose_client_contacts"] = "Escolha os contatos do cliente";
$lang["microsoft_teams_integration_upcoming"] = "Próximos";
$lang["microsoft_teams_integration_recent"] = "Recentes";
$lang["microsoft_teams_integration_past"] = "Passado";

return $lang;
