<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["microsoft_teams_integration"] = "Microsoft Teams-integratie";
$lang["microsoft_teams_integration_meetings"] = "Vergaderingen";
$lang["microsoft_teams_integration_topic"] = "Onderwerp";
$lang["microsoft_team_meetings"] = "Teams-vergaderingen";
$lang["microsoft_teams_integration_join_meeting"] = "Deelnemen aan vergadering";
$lang["microsoft_teams_integration_other_settings"] = "Andere instellingen";
$lang["microsoft_teams_integration_integrate_microsoft_teams"] = "Microsoft Teams integreren";
$lang["microsoft_teams_integration_who_can_manage_meetings"] = "Wie kan vergaderingen beheren";
$lang["microsoft_teams_integration_users_help_message"] = "Specificeer alleen niet-beheerdersteamleden. Beheerders krijgen altijd toegang.";
$lang["microsoft_teams_integration_client_can_access_meetings"] = "Klant heeft toegang tot vergaderingen?";
$lang["microsoft_teams_integration_meeting_time"] = "Vergadertijd";
$lang["microsoft_teams_integration_join_url"] = "Deelnemen aan URL";
$lang["microsoft_teams_integration_add_meeting"] = "Vergadering toevoegen";
$lang["microsoft_teams_integration_edit_meeting"] = "Vergadering bewerken";
$lang["microsoft_teams_integration_delete_meeting"] = "Verwijder vergadering";
$lang["microsoft_teams_integration_all_client_contacts"] = "Alle klantcontacten";
$lang["microsoft_teams_integration_choose_client_contacts"] = "Kies klantcontacten";
$lang["microsoft_teams_integration_upcoming"] = "Aankomend";
$lang["microsoft_teams_integration_recent"] = "Recent";
$lang["microsoft_teams_integration_past"] = "Verleden";

return $lang;
