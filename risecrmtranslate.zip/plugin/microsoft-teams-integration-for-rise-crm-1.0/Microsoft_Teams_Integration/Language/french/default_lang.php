<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["microsoft_teams_integration"] = "Intégration Microsoft Teams";
$lang["microsoft_teams_integration_meetings"] = "Réunions";
$lang["microsoft_teams_integration_topic"] = "Sujet";
$lang["microsoft_team_meetings"] = "Réunions Teams";
$lang["microsoft_teams_integration_join_meeting"] = "Rejoindre la réunion";
$lang["microsoft_teams_integration_other_settings"] = "Autres paramètres";
$lang["microsoft_teams_integration_integrate_microsoft_teams"] = "Intégrer Microsoft Teams";
$lang["microsoft_teams_integration_who_can_manage_meetings"] = "Qui peut gérer les réunions";
$lang["microsoft_teams_integration_users_help_message"] = "Spécifiez uniquement les membres de l'équipe non-administrateurs. Les administrateurs auront toujours accès.";
$lang["microsoft_teams_integration_client_can_access_meetings"] = "Le client peut accéder aux réunions ?";
$lang["microsoft_teams_integration_meeting_time"] = "Heure de la réunion";
$lang["microsoft_teams_integration_join_url"] = "Rejoindre l'URL";
$lang["microsoft_teams_integration_add_meeting"] = "Ajouter une réunion";
$lang["microsoft_teams_integration_edit_meeting"] = "Modifier la réunion";
$lang["microsoft_teams_integration_delete_meeting"] = "Supprimer la réunion";
$lang["microsoft_teams_integration_all_client_contacts"] = "Tous les contacts clients";
$lang["microsoft_teams_integration_choose_client_contacts"] = "Choisir les contacts clients";
$lang["microsoft_teams_integration_upcoming"] = "À venir";
$lang["microsoft_teams_integration_recent"] = "Récent";
$lang["microsoft_teams_integration_past"] = "Passé";

return $lang;
