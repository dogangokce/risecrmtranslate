<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["microsoft_teams_integration"] = "Integración de Microsoft Teams";
$lang["microsoft_teams_integration_meetings"] = "Reuniones";
$lang["microsoft_teams_integration_topic"] = "Tema";
$lang["microsoft_team_meetings"] = "Reuniones de Teams";
$lang["microsoft_teams_integration_join_meeting"] = "Unirse a la reunión";
$lang["microsoft_teams_integration_other_settings"] = "Otras configuraciones";
$lang["microsoft_teams_integration_integrate_microsoft_teams"] = "Integrar Microsoft Teams";
$lang["microsoft_teams_integration_who_can_manage_meetings"] = "Quién puede gestionar reuniones";
$lang["microsoft_teams_integration_users_help_message"] = "Especifique solo los miembros del equipo que no sean administradores. Los administradores siempre tendrán acceso.";
$lang["microsoft_teams_integration_client_can_access_meetings"] = "¿El cliente puede acceder a las reuniones?";
$lang["microsoft_teams_integration_meeting_time"] = "Hora de la reunión";
$lang["microsoft_teams_integration_join_url"] = "URL de ingreso";
$lang["microsoft_teams_integration_add_meeting"] = "Agregar reunión";
$lang["microsoft_teams_integration_edit_meeting"] = "Editar reunión";
$lang["microsoft_teams_integration_delete_meeting"] = "Eliminar reunión";
$lang["microsoft_teams_integration_all_client_contacts"] = "Todos los contactos del cliente";
$lang["microsoft_teams_integration_choose_client_contacts"] = "Elija los contactos del cliente";
$lang["microsoft_teams_integration_upcoming"] = "Próximo";
$lang["microsoft_teams_integration_recent"] = "Reciente";
$lang["microsoft_teams_integration_past"] = "Pasado";

return $lang;
