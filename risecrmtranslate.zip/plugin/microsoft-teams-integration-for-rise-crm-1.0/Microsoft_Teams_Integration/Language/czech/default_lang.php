<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["microsoft_teams_integration"] = "Integrace Microsoft Teams";
$lang["microsoft_teams_integration_meetings"] = "Schůzky";
$lang["microsoft_teams_integration_topic"] = "Téma";
$lang["microsoft_team_meetings"] = "Schůzky přes Teams";
$lang["microsoft_teams_integration_join_meeting"] = "Připojit se ke schůzce";
$lang["microsoft_teams_integration_other_settings"] = "Další nastavení";
$lang["microsoft_teams_integration_integrate_microsoft_teams"] = "Integrovat Microsoft Teams";
$lang["microsoft_teams_integration_who_can_manage_meetings"] = "Kdo může řídit schůzky";
$lang["microsoft_teams_integration_users_help_message"] = "Uveďte pouze členy týmu, kteří nejsou administrátory. Správci budou mít přístup vždy.";
$lang["microsoft_teams_integration_client_can_access_meetings"] = "Klient má přístup ke schůzkám?";
$lang["microsoft_teams_integration_meeting_time"] = "Čas schůzky";
$lang["microsoft_teams_integration_join_url"] = "Připojit URL";
$lang["microsoft_teams_integration_add_meeting"] = "Přidat schůzku";
$lang["microsoft_teams_integration_edit_meeting"] = "Upravit schůzku";
$lang["microsoft_teams_integration_delete_meeting"] = "Smazat schůzku";
$lang["microsoft_teams_integration_all_client_contacts"] = "Všechny klientské kontakty";
$lang["microsoft_teams_integration_choose_client_contacts"] = "Vyberte kontakty klienta";
$lang["microsoft_teams_integration_upcoming"] = "Připravované";
$lang["microsoft_teams_integration_recent"] = "Nedávné";
$lang["microsoft_teams_integration_past"] = "Minulost";

return $lang;
