<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["social_login"] = "Sosial pålogging";
$lang["social_login_enable_google_login"] = "Aktiver Google -pålogging";
$lang["social_login_login_password_help_message"] = "Angi det fra kontoinnstillingen";
$lang["social_login_duplicate_company_name"] = "Dupliser firmanavn";
$lang["social_login_continue_with_google"] = "Fortsett med Google";
$lang["social_login_enable_facebook_login"] = "Aktiver Facebook -pålogging";
$lang["social_login_continue_with_facebook"] = "Fortsett med Facebook";
$lang["social_login_remember_to_add_this_url_in_valid_oauth_redirect_uris"] = "Husk å legge til denne nettadressen i gyldige OAuth -omdirigerings -URIer";
$lang["social_login_facebook_https_error_help_message"] = "Facebook -pålogging fungerer bare på HTTPS -server.";

return $lang;
