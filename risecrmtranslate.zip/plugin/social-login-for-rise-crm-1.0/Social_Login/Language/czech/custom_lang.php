<?php //default_lang.php dosyasından kopyala ve güncelle

$lang["social_login_example"] = "Örnek";

return $lang;