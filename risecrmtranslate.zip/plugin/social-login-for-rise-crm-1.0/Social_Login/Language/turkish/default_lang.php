<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["social_login"] = "Sosyal Giriş";
$lang["social_login_enable_google_login"] = "Google Girişi Etkinleştir";
$lang["social_login_login_password_help_message"] = "Lütfen hesap ayarlarından belirleyin";
$lang["social_login_duplicate_company_name"] = "Firma adı zaten kullanılıyor";
$lang["social_login_continue_with_google"] = "Google ile Devam Et";
$lang["social_login_enable_facebook_login"] = "Facebook Girişi Etkinleştir";
$lang["social_login_continue_with_facebook"] = "Facebook ile Devam Et";
$lang["social_login_remember_to_add_this_url_in_valid_oauth_redirect_uris"] = "Bu URL'yi Geçerli OAuth Yönlendirmelerine Eklemeyi Unutmayın";
$lang["social_login_facebook_https_error_help_message"] = "Facebook girişi yalnızca HTTPS sunucularında çalışır.";

return $lang;
