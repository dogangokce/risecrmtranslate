<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["social_login"] = "Sociale login";
$lang["social_login_enable_google_login"] = "Google Login inschakelen";
$lang["social_login_login_password_help_message"] = "Stel dit in via uw accountinstelling";
$lang["social_login_duplicate_company_name"] = "Dubbele bedrijfsnaam";
$lang["social_login_continue_with_google"] = "Doorgaan met Google";
$lang["social_login_enable_facebook_login"] = "Facebook-aanmelding inschakelen";
$lang["social_login_continue_with_facebook"] = "Doorgaan met Facebook";
$lang["social_login_remember_to_add_this_url_in_valid_oauth_redirect_uris"] = "Vergeet niet om deze url toe te voegen aan geldige OAuth-omleidings-URI's";
$lang["social_login_facebook_https_error_help_message"] = "Facebook-aanmelding werkt alleen op HTTPS-server.";

return $lang;
