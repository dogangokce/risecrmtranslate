<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["jitsi_integration"] = "Intégration Jitsi";
$lang["jitsi_integration_meetings"] = "Réunions";
$lang["jitsi_integration_topic"] = "Sujet";
$lang["jitsi_meetings"] = "Réunions Jitsi";
$lang["jitsi_integration_join_meeting"] = "Rejoindre la réunion";
$lang["jitsi_integration_enable_jitsi_meetings"] = "Activer les réunions Jitsi";
$lang["jitsi_integration_who_can_manage_meetings"] = "Qui peut gérer les réunions";
$lang["jitsi_integration_users_help_message"] = "Spécifiez uniquement les membres de l'équipe non-administrateurs. Les administrateurs auront toujours accès.";
$lang["jitsi_integration_client_can_access_meetings"] = "Le client peut accéder aux réunions ?";
$lang["jitsi_integration_meeting_time"] = "Heure de la réunion";
$lang["jitsi_integration_join_url"] = "Rejoindre l'URL";
$lang["jitsi_integration_add_meeting"] = "Ajouter une réunion";
$lang["jitsi_integration_edit_meeting"] = "Modifier la réunion";
$lang["jitsi_integration_delete_meeting"] = "Supprimer la réunion";
$lang["jitsi_integration_all_client_contacts"] = "Tous les contacts clients";
$lang["jitsi_integration_choose_client_contacts"] = "Choisir les contacts clients";
$lang["jitsi_integration_upcoming"] = "À venir";
$lang["jitsi_integration_recent"] = "Récent";
$lang["jitsi_integration_past"] = "Past";

return $lang;
