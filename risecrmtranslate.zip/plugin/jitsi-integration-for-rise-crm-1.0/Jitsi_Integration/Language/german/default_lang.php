<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["jitsi_integration"] = "Jitsi-Integration";
$lang["jitsi_integration_meetings"] = "Besprechungen";
$lang["jitsi_integration_topic"] = "Thema";
$lang["jitsi_meetings"] = "Jitsi-Treffen";
$lang["jitsi_integration_join_meeting"] = "Meeting beitreten";
$lang["jitsi_integration_enable_jitsi_meetings"] = "Jitsi-Meetings aktivieren";
$lang["jitsi_integration_who_can_manage_meetings"] = "Wer kann Meetings verwalten";
$lang["jitsi_integration_users_help_message"] = "Geben Sie nur Nicht-Administrator-Teammitglieder an. Administratoren erhalten immer Zugriff.";
$lang["jitsi_integration_client_can_access_meetings"] = "Kunde kann auf Meetings zugreifen?";
$lang["jitsi_integration_meeting_time"] = "Besprechungszeit";
$lang["jitsi_integration_join_url"] = "Beitritts-URL";
$lang["jitsi_integration_add_meeting"] = "Meeting hinzufügen";
$lang["jitsi_integration_edit_meeting"] = "Meeting bearbeiten";
$lang["jitsi_integration_delete_meeting"] = "Meeting löschen";
$lang["jitsi_integration_all_client_contacts"] = "Alle Kundenkontakte";
$lang["jitsi_integration_choose_client_contacts"] = "Kundenkontakte auswählen";
$lang["jitsi_integration_upcoming"] = "Bevorstehend";
$lang["jitsi_integration_recent"] = "Neueste";
$lang["jitsi_integration_past"] = "Vergangenheit";

return $lang;
