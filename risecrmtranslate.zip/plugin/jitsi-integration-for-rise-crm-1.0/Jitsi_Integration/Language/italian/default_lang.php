<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["jitsi_integration"] = "Integrazione Jitsi";
$lang["jitsi_integration_meetings"] = "Incontri";
$lang["jitsi_integration_topic"] = "Argomento";
$lang["jitsi_meetings"] = "Incontri Jitsi";
$lang["jitsi_integration_join_meeting"] = "Partecipa alla riunione";
$lang["jitsi_integration_enable_jitsi_meetings"] = "Abilita riunioni Jitsi";
$lang["jitsi_integration_who_can_manage_meetings"] = "Chi può gestire le riunioni";
$lang["jitsi_integration_users_help_message"] = "Specifica solo i membri del team non amministratori. Gli amministratori avranno sempre accesso.";
$lang["jitsi_integration_client_can_access_meetings"] = "Il cliente può accedere alle riunioni?";
$lang["jitsi_integration_meeting_time"] = "Ora della riunione";
$lang["jitsi_integration_join_url"] = "URL di partecipazione";
$lang["jitsi_integration_add_meeting"] = "Aggiungi riunione";
$lang["jitsi_integration_edit_meeting"] = "Modifica riunione";
$lang["jitsi_integration_delete_meeting"] = "Elimina riunione";
$lang["jitsi_integration_all_client_contacts"] = "Tutti i contatti del cliente";
$lang["jitsi_integration_choose_client_contacts"] = "Scegli i contatti del cliente";
$lang["jitsi_integration_upcoming"] = "Prossimo";
$lang["jitsi_integration_recent"] = "Recente";
$lang["jitsi_integration_past"] = "Passato";

return $lang;
