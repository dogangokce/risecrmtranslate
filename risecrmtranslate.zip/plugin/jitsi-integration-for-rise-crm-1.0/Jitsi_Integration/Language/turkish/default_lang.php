<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["jitsi_integration"] = "Jitsi Entegrasyonu";
$lang["jitsi_integration_meetings"] = "Toplantılar";
$lang["jitsi_integration_topic"] = "Konu";
$lang["jitsi_meetings"] = "Jitsi toplantıları";
$lang["jitsi_integration_join_meeting"] = "Toplantıya katıl";
$lang["jitsi_integration_enable_jitsi_meetings"] = "Jitsi toplantılarını etkinleştir";
$lang["jitsi_integration_who_can_manage_meetings"] = "Kim toplantıları yönetebilir?";
$lang["jitsi_integration_users_help_message"] = "Yönetici olmayan takım üyelerini belirtin. Yöneticiler her zaman erişebilir.";
$lang["jitsi_integration_client_can_access_meetings"] = "Müşteri toplantılara erişebilir mi?";
$lang["jitsi_integration_meeting_time"] = "Toplantı zamanı";
$lang["jitsi_integration_join_url"] = "Katılma URL'si";
$lang["jitsi_integration_add_meeting"] = "Toplantı ekle";
$lang["jitsi_integration_edit_meeting"] = "Toplantıyı düzenle";
$lang["jitsi_integration_delete_meeting"] = "Toplantıyı sil";
$lang["jitsi_integration_all_client_contacts"] = "Tüm müşteri iletişimleri";
$lang["jitsi_integration_choose_client_contacts"] = "Müşteri iletişimlerini seçin";
$lang["jitsi_integration_upcoming"] = "Yaklaşan";
$lang["jitsi_integration_recent"] = "Son zamanlar";
$lang["jitsi_integration_past"] = "Geçmiş";

return $lang;
