<?php

/* NOT: BU DOSYAYI DEĞİŞTİRMEYİNİZ. DİLİ GÜNCELLEMEK İSTİYORSANIZ, BU DOSYAYI custom_lang.php ADLI BİR DOSYAYA KOYUP ORADA GÜNCELLEYİN */

$lang["jitsi_integration"] = "Integracja Jitsi";
$lang["jitsi_integration_meetings"] = "Spotkania";
$lang["jitsi_integration_topic"] = "Temat";
$lang["jitsi_meetings"] = "Spotkania Jitsi";
$lang["jitsi_integration_join_meeting"] = "Dołącz do spotkania";
$lang["jitsi_integration_enable_jitsi_meetings"] = "Włącz spotkania Jitsi";
$lang["jitsi_integration_who_can_manage_meetings"] = "Kto może zarządzać spotkaniami";
$lang["jitsi_integration_users_help_message"] = "Określ tylko członków zespołu niebędących administratorami. Administratorzy zawsze będą mieli dostęp.";
$lang["jitsi_integration_client_can_access_meetings"] = "Klient ma dostęp do spotkań?";
$lang["jitsi_integration_meeting_time"] = "Czas spotkania";
$lang["jitsi_integration_join_url"] = "Dołącz URL";
$lang["jitsi_integration_add_meeting"] = "Dodaj spotkanie";
$lang["jitsi_integration_edit_meeting"] = "Edytuj spotkanie";
$lang["jitsi_integration_delete_meeting"] = "Usuń spotkanie";
$lang["jitsi_integration_all_client_contacts"] = "Wszystkie kontakty klientów";
$lang["jitsi_integration_choose_client_contacts"] = "Wybierz kontakty klienta";
$lang["jitsi_integration_upcoming"] = "Nadchodzące";
$lang["jitsi_integration_recent"] = "Najnowsze";
$lang["jitsi_integration_past"] = "Przeszłość";

return $lang;
